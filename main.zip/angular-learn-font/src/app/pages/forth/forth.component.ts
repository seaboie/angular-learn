import { Component } from '@angular/core';

@Component({
  selector: 'app-forth',
  imports: [],
  templateUrl: './forth.component.html',
  styleUrl: './forth.component.css'
})
export class ForthComponent {

}
